import pool from './config/database.js';

(async () => {
  try {
    const res = await pool.query('SELECT NOW() as now');
    console.log('DB_OK:', res.rows[0]);
    await pool.end();
    process.exit(0);
  } catch (err) {
    console.error('DB_ERR:', err.message || err);
    try { await pool.end(); } catch (e) {}
    process.exit(1);
  }
})();
