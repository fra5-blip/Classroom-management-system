import { initializeTables } from './config/schema.js';
import pool from './config/database.js';

// Try to load dotenv if available; continue if not installed yet.
try {
  // dynamic import so script doesn't fail if dotenv isn't installed
  // eslint-disable-next-line no-await-in-loop
  const dotenv = await import('dotenv');
  dotenv.config();
} catch (e) {
  // dotenv not available yet (likely before npm install). Continue anyway.
}

(async () => {
  try {
    await initializeTables();
    console.log('Database initialized successfully');

    // Use the shared seed module so seeding logic is centralized
    try {
      const { seedAll } = await import('./config/seed.js')
      await seedAll()
      console.log('Seeded data successfully')
    } catch (e) {
      console.error('Seeding failed', e)
    }

    if (pool && typeof pool.end === 'function') {
      try { await pool.end(); } catch (e) {}
    }
    process.exit(0);
  } catch (err) {
    console.error('Failed to initialize database:', err);
    if (pool && typeof pool.end === 'function') {
      try { await pool.end(); } catch (e) {}
    }
    process.exit(1);
  }
})();
