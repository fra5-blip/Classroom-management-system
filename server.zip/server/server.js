import dotenv from 'dotenv';
import express from 'express';
import cors from 'cors';
import authRoutes from './routes/auth.js';
import classroomRoutes from './routes/classrooms.js';
import studentRoutes from './routes/student.js';
import adminRoutes from './routes/admin.js';
let debugRoutes
import { initializeTables } from './config/schema.js';

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

app.get('/', (req, res) => res.json({ status: 'ok', msg: 'Backend running' }));

app.use('/api/auth', authRoutes);
app.use('/api/classrooms', classroomRoutes);
app.use('/api/student', studentRoutes);
app.use('/api/admin', adminRoutes);

// Mount debug routes only in non-production environments
if (process.env.NODE_ENV !== 'production') {
  try {
    // dynamic import so production bundles won't include debug code
    const mod = await import('./routes/debug.js')
    debugRoutes = mod.default
    app.use('/api/debug', debugRoutes)
  } catch (e) {
    console.error('Failed to mount debug routes', e)
  }
}

const PORT = process.env.PORT || 5000;

export default app;

// Start the server and initialize DB only when not running tests
if (process.env.NODE_ENV !== 'test') {
  (async () => {
    try {
      await initializeTables();
      // auto-seed in development to ensure demo data is present
      if (process.env.NODE_ENV !== 'production') {
        try {
          const { seedAll } = await import('./config/seed.js')
          await seedAll()
          console.log('Auto-seeded demo data on startup')
        } catch (e) {
          console.error('Auto-seeding failed', e)
        }
      }
    } catch (err) {
      console.error('Failed to initialize tables on startup:', err);
    }

    app.listen(PORT, () => {
      console.log(`Server listening on port ${PORT}`);
    });
  })();
}
