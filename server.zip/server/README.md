# Classroom Management Backend (server)

This is the backend for the Classroom Management app. It can run with PostgreSQL or use the included SQLite fallback for local development.

## Prerequisites
- Node.js (recommended 16+ / works with newer versions)
- npm

## Quickstart (SQLite, local)
1. Install dependencies

```bash
cd server
npm install
```

2. Initialize the database (creates `server/db.sqlite` by default)

```bash
set DB_CLIENT=sqlite   # on Windows (cmd)
# or on PowerShell: $env:DB_CLIENT = 'sqlite'
npm run init-db
```

3. Start the dev server

```bash
set DB_CLIENT=sqlite
npm run dev
```

4. Health checks

```bash
curl http://localhost:5000/health
curl http://localhost:5000/
```

## Quickstart (Postgres)
Set the Postgres environment variables and then run `npm run init-db`.

Required env vars (example):
```
DB_HOST=localhost
DB_PORT=5432
DB_USER=postgres
DB_PASSWORD=yourpassword
DB_NAME=classroom_management
```

## Tests
Run the Jest test suite:

```bash
cd server
npm test
```

## Environment
See the sample environment file: `.env.example` for the variables used by the server. For production, set `JWT_SECRET` to a strong secret.

## Files of interest
- `server.js` — app entry point
- `init-db.js` — schema initialization
- `config/` — database adapters and schema
- `models/`, `controllers/`, `routes/` — application logic

If you want, I can add a short badge or expand this README with API examples.\
